class credits extends Phaser.Scene {
    constructor() {
      super({ key: "credits" });
    }
    preload() {
        this.load.image(
            "exit", "./img/exit.jpeg"
        );
    }
    create() {
        let exit = this.add.image(config.width / 2, config.height / 2, "exit");
        exit.setInteractive();
        exit.on("pointerdown", () => {
          this.scene.start("Accueil");
        });
    }
    update() {}
  }