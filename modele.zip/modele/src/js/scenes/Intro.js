class Intro extends Phaser.Scene {
    constructor() {
        super({ key: "Accueil" });
    }

    preload() {
        this.load.image(
            "bg", "./img/bg_intro.webp"
        );
        this.load.image(
            "logo", "./img/logo_intro.avif"
        );
        this.load.image(
            "play", "./img/play.png"
        );
        this.load.image(
            "credits", "./img/credits.png"
        );
        this.load.image(
            "info", "./img/info.png"
        );
        this.load.image(
            "audio", "./img/audio.png"
        )
    }

    create() {

        let bg = this.add.image(config.width / 2, config.height / 2, "bg");
        
        let logo = this.add.image(config.width / 2, config.height / 2, "logo");
        logo.setScale(0.2);
        logo.setOrigin(1,1);
        logo.setPosition(565, 200)

        let play = this.add.image(config.width / 2, config.height / 2, "play");
        play.setScale(0.2)
        play.setInteractive();
        play.on("pointerdown", () => {
          this.scene.start("jeu");
        });

        let credits = this.add.image(config.width / 2, config.height / 2, "credits");
        credits.setScale(0.4)
        credits.setPosition(800, 600)
        credits.setInteractive();
        credits.on("pointerdown", () => {
          this.scene.start("credits");
        });

        let info = this.add.image(config.width / 2, config.height / 2, "info");
        info.setScale(0.1)
        info.setPosition(200, 600)
        info.setInteractive();
        info.on("pointerdown", () => {
          this.scene.start("comment_jouer");
        });

        let audio = this.add.image(config.width / 2, config.height / 2, "audio");
        audio.setScale(0.1)
        audio.setPosition(100, 600)
    }

    update() {

    }
}