class jeu extends Phaser.Scene {
    constructor() {
      super({ key: "jeu" });
    }
    preload() {
        this.load.image(
            "exit", "./img/exit.jpeg"
        );
    }
    create() {
        let exit = this.add.image(config.width / 2, config.height / 2, "exit");
        exit.setInteractive();
        exit.on("pointerdown", () => {
          this.scene.start("Accueil");
        });
    }
    update() {}
  }