const config = {
    type: Phaser.AUTO,
    parent: "canvas-wrapper",
    width: 1000,
    height: 800,
    scene: [Intro, jeu, info, credits, finish, victoire],
    transparent: true
};
const game = new Phaser.Game(config);

